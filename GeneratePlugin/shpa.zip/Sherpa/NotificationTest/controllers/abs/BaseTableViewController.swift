//
//  BaseTableViewController.swift
//  Sherpa
//
//  Created by Dmitry on 5/20/15.
//  Copyright (c) 2015 magnet. All rights reserved.
//

import Foundation

class BaseTableViewController:UITableViewController {
    
    override func prefersStatusBarHidden() -> Bool {
        return true;
    }
    
}
