//
//  SetUpTravelCollectionCell.swift
//  Sherpa
//
//  Created by Dmitry on 5/21/15.
//  Copyright (c) 2015 magnet. All rights reserved.
//

import UIKit

class SetUpTravelCollectionCell: BaseCollectionViewCell {

    override func onCreate() {
        
    }
    
    override func getHeigh() -> Int {
        return 80;
    }

}
