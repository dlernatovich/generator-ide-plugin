//
//  NavigationConstants.swift
//  NotificationTest
//
//  Created by Dmitry on 5/18/15.
//  Copyright (c) 2015 magnet. All rights reserved.
//

import Foundation

class NavigationConstants:NSObject {
    static let kNavigationMain:String! = "signInScreen";
    static let kNavigationHome:String! = "sequeToHome";
}
